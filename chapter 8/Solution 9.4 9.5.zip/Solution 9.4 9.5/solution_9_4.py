class Restaurant():
    """A class representing a restaurant."""

    def __init__(self, name, cuisine_type):
        """Initialize the restaurant."""
        # initializes the name of the restaurant
        self.name = name.title()
        # initializes the type of food served
        self.cuisine_type = cuisine_type
        # initializes the number of customers served. Every attribute in a
        # class needs an initial value, even if that value is 0 or an empty
        # string. In some cases, such as when setting a default value, it makes
        # sense to specify this initial value in the body of the __init__()
        # method; if you do this for an attribute, you don’t have to include a
        # parameter for that attribute.
        self.number_served = 0

    def describe_restaurant(self):
        """Display a summary of the restaurant."""
        # defines a message to print about the restaurant
        msg = self.name + " serves wonderful " + self.cuisine_type + "."
        # adds a blank line before printing the message
        print("\n" + msg)

    def open_restaurant(self):
        """Display a message that the restaurant is open."""
        # defines a message to print about when the restaurant is open
        msg = self.name + " is open. Come on in!"
        # adds a new line before printing the message
        print("\n" + msg)

    def set_number_served(self, number_served):
        """Allow user to set the number of customers that have been served."""
        self.number_served = number_served

    def increment_number_served(self, additional_served):
        """Allow user to increment the number of customers served."""
        self.number_served += additional_served

# defines the variable restaurant to use class Restaurant
# This action makes it more simple later for printing
restaurant = Restaurant('the mean queen', 'pizza')
restaurant.describe_restaurant()
# prints the number served based on the default value 0
print("\nNumber served: " + str(restaurant.number_served))
# changes the number_served to 430 and prints the new value
restaurant.number_served = 430
print("Number served: " + str(restaurant.number_served))
# sets the number_served to 1257 and prints the new value
restaurant.set_number_served(1257)
print("Number served: " + str(restaurant.number_served))
# takes the previous number_served and increases the ammount by 239 and prints
# the new value
restaurant.increment_number_served(239)
print("Number served: " + str(restaurant.number_served))
