class User():
    """Represent a simple user profile."""

    def __init__(self, first_name, last_name, username, email, location):
        """Initialize the user."""
        # initializes the first name of the user
        self.first_name = first_name.title()
        # initializes the last name of the user
        self.last_name = last_name.title()
        # initializes the username
        self.username = username
        # initializes the user's email address
        self.email = email
        # initializes the user's location
        self.location = location.title()
        # initializes the login attempts. Every attribute in a
        # class needs an initial value, even if that value is 0 or an empty
        # string. In some cases, such as when setting a default value, it makes
        # sense to specify this initial value in the body of the __init__()
        # method; if you do this for an attribute, you don’t have to include a
        # parameter for that attribute.
        self.login_attempts = 0

    def describe_user(self):
        """Display a summary of the user's information."""
        # prints the user's name on a new line
        print("\n" + self.first_name + " " + self.last_name)
        # prints the username, email, and location
        print("  Username: " + self.username)
        print("  Email: " + self.email)
        print("  Location: " + self.location)

    def greet_user(self):
        """Display a personalized greeting to the user."""
        # prints a greeting on a new line using the username
        print("\nWelcome back, " + self.username + "!")

    def increment_login_attempts(self):
        """Increment the value of login_attempts."""
        self.login_attempts += 1

    def reset_login_attempts(self):
        """Reset login_attempts to 0."""
        self.login_attempts = 0

# creates the first object of the User class for Eric Matthes
eric = User('eric', 'matthes', 'e_matthes', 'e_matthes@example.com', 'alaska')
eric.describe_user()
eric.greet_user()
# creates the fsecond object of the User class for Willie Burger
willie = User('willie', 'burger', 'willieburger', 'wb@example.com', 'alaska')
willie.describe_user()
willie.greet_user()
# increasing the value of login_attempts and prints the value
print("\nMaking 3 login attempts...")
eric.increment_login_attempts()
eric.increment_login_attempts()
eric.increment_login_attempts()
print("  Login attempts: " + str(eric.login_attempts))
# resets the number of login attempts for the user
print("Resetting login attempts...")
eric.reset_login_attempts()
print("  Login attempts: " + str(eric.login_attempts))
